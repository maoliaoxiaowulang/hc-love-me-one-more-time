import { _decorator, Color, Component, Graphics, Vec2,Sprite, EventTouch, Vec3, v3,Node, v2,instantiate, Prefab, Camera, director, Root} from 'cc';
import { global } from './global';
import { WECHAT_MINI_PROGRAM } from 'cc/env';
const { ccclass, property } = _decorator;

@ccclass('planemove')
export class planemove extends Component {

    @property(Node)
    spriteNode: Node= null;  // 拖动的精灵节点

    @property
    maxDragDistance: number = 150;  // 最大拖动距离，只有在触摸点离精灵位置较近时才开始拖动

    // 存储初始位置
    private startPos: Vec3 = new Vec3();
    // 存储精灵的起始偏移量
    private offset: Vec3 = new Vec3();
    // 标记是否允许移动
    private canMove: boolean = false;
    private map: Map<Node, number> = new Map();
    private mapnumber:number = 0;
    
    private cloneplanes = new Set<Node>();
    

    @property(Camera)
    clonecamera:Camera = null;
   

    @property
    cellside: number = 120; // 每个单元格边长为50

    // 网格的行数和列数
    @property
    rows: number = 10;

    @property
    cols: number = 10;

    @property(Prefab)
    cloneplane: Prefab = null;

    private lastTouchTime: number = 0;  // 上一次点击的时间
    private doubleClickInterval: number = 300;  // 双击间隔 (单位：毫秒)
    start() {
          // 使用 position 设置位置

        // 监听精灵的触摸/鼠标事件
        this.spriteNode.on(Node.EventType.TOUCH_START, this.copy_plane, this);
        
       
    
    }

    update(deltaTime: number) {
        
    }
        copy_plane(event:EventTouch){
            this.startPos.set(this.spriteNode.position);
            const clonedSprite = instantiate(this.cloneplane);
            this.map.set(clonedSprite,this.mapnumber);
            this.mapnumber+=1;
            
            this.spriteNode.parent.parent.addChild(clonedSprite);
            clonedSprite.position = new Vec3(0,0,0);
            this.cloneplanes.add(clonedSprite);
            
            if(global.currentnode){
                
                
                let plane = global.currentnode.getChildByName('plane');
                let children = plane.children;
            for(let child of children){
                child.off(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
                
                
                
            }
           
                
                
            }
            global.currentnode = clonedSprite;
            let plane = global.currentnode.getChildByName('plane');
            let children = plane.children;
            for(let child of children){
                child.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
                
                child.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
                
            }
            global.currentnode.on('planedestory', this.removeevent, this);
            director.on('destory', this.removeevent, this);
            
            
            

        }

        




        // 触摸开始时的处理
        onTouchStart(event: EventTouch) {

            console.log('ontouchstart')
            if(global.currentnode){
                let plane = global.currentnode.getChildByName('plane');
                let children = plane.children;
                for(let child of children){
                  child.off(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
                  
            }
              
            }
        
            global.currentnode = event.target.parent.parent as Node;
            
            
            
            let plane = global.currentnode.getChildByName('plane');
            let children = plane.children;
            for(let child of children){
                child.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
                
                child.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
                
            }
            global.currentnode.on('planedestory', this.removeevent, this);
           
        }
    
        // 触摸移动时的处理
        onTouchMove(event: EventTouch) {
            //if (!this.canMove) return;  // 如果不允许移动，则直接返回
            const clonedSprite = event.target.parent.parent as Node;
            let pos = event.getLocation();
        
            let out = new Vec3;
            this.clonecamera.screenToWorld(v3(pos.x,pos.y),out);
            
            clonedSprite.setWorldPosition(out);
            
            clonedSprite.position=this.alignToGrid(clonedSprite.position)
            
           
        }
    
        
    

        

        

        removeevent(){
            console.log(this.map.get(global.currentnode));
            
            let plane = global.currentnode.getChildByName('plane');
            let children = plane.children;
            for(let child of children){
            child.off(Node.EventType.TOUCH_START, this.onTouchStart, this);
            child.off(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
           
            ;}
          
            
            this.cloneplanes.delete(global.currentnode);
            global.currentnode.destroy();
            if(Array.from(this.cloneplanes).length >0){
                
               
               global.currentnode = Array.from(this.cloneplanes)[Array.from(this.cloneplanes).length-1];
            
               let plane2 = global.currentnode.getChildByName('plane');
               let children2 = plane2.children;
               for(let child of children2){
               child.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
               child.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
               
               ;}
            
               global.currentnode.on('planedestory', this.removeevent, this)}
            else{global.currentnode=null;}
            
        }
      


        public turn() {
            
            if (global.currentnode) {
                // 执行旋转逻辑
                global.currentnode.angle += 90;
            }
        }
        
   

        // 对齐到网格
        alignToGrid(position: Vec3) {
            // 计算精灵占用的网格区域的中心位置，精灵的中心应当对齐到网格中心
            var alignedX = Math.floor(position.x  / this.cellside) * this.cellside +this.cellside/2 ;
            var alignedY = Math.floor(position.y / this.cellside) * this.cellside +this.cellside/2 ;
            if(global.currentnode.angle%360 == 0){
                if (alignedX > this.cols*this.cellside/2-this.cellside*5/2) alignedX=this.cols*this.cellside/2-this.cellside*5/2
                if (alignedX < -this.cols*this.cellside/2+5/2*this.cellside) alignedX=-this.cols*this.cellside/2+5/2*this.cellside
                if (alignedY > this.rows*this.cellside/2-3/2*this.cellside) alignedY=this.rows*this.cellside/2-3/2*this.cellside
                if (alignedY < -this.rows*this.cellside/2+5/2*this.cellside) alignedY=-this.rows*this.cellside/2+5/2*this.cellside}
     
             if(global.currentnode.angle%360 == 90){
                 if (alignedX > this.cols*this.cellside/2-this.cellside*5/2) alignedX=this.cols*this.cellside/2-this.cellside*5/2
                 if (alignedX < -this.cols*this.cellside/2+3/2*this.cellside) alignedX=-this.cols*this.cellside/2+3/2*this.cellside
                 if (alignedY > this.rows*this.cellside/2-this.cellside*5/2) alignedY=this.rows*this.cellside/2-this.cellside*5/2
                 if (alignedY < -this.rows*this.cellside/2+5/2*this.cellside) alignedY=-this.rows*this.cellside/2+5/2*this.cellside}
     
             if(global.currentnode.angle%360 == 180){
                 if (alignedX > this.cols*this.cellside/2-this.cellside*5/2) alignedX=this.cols*this.cellside/2-this.cellside*5/2
                 if (alignedX < -this.cols*this.cellside/2+5/2*this.cellside) alignedX=-this.cols*this.cellside/2+5/2*this.cellside
                 if (alignedY > this.rows*this.cellside/2-this.cellside*5/2) alignedY=this.rows*this.cellside/2-this.cellside*5/2
                 if (alignedY < -this.rows*this.cellside/2+3/2*this.cellside) alignedY=-this.rows*this.cellside/2+3/2*this.cellside}
     
             if(global.currentnode.angle%360 == 270){
                 if (alignedX > this.cols*this.cellside/2-this.cellside*3/2) alignedX=this.cols*this.cellside/2-this.cellside*3/2
                 if (alignedX < -this.cols*this.cellside/2+5/2*this.cellside) alignedX=-this.cols*this.cellside/2+5/2*this.cellside
                 if (alignedY > this.rows*this.cellside/2-this.cellside*5/2) alignedY=this.rows*this.cellside/2-this.cellside*5/2
                 if (alignedY < -this.rows*this.cellside/2+5/2*this.cellside) alignedY=-this.rows*this.cellside/2+5/2*this.cellside}
            return new Vec3(alignedX, alignedY, position.z);
            }
    }
    



