export const globalstarnum = {




    starnum1:0,
    starnum2:0,
    starnum3:0,
    starnum4:0,
    starnum5:0,
    starnum6:0,
    starnum7:0,
    starnum8:0,
    starnum9:0,
    starnum10:0,
    starnum11:0,
    starnum12:0,
    starnum13:0,
    starnum14:0,
    starnum15:0,
    starnum16:0,
    starnum17:0,
    starnum18:0,
    starnum19:0,
    starnum20:0,
    starnum21:0,
    starnum22:0,
    starnum23:0,
    starnum24:0,

    startotal:0,
    coststar:0,
    leftstar:0,
    rocketnum:0,
    leidanum:0,
    bigglassnum:0,

    have1:0,
    have2:0,
    have3:0,
    have4:0,
    have5:0,
    have6:0,
    have7:0,
    have8:0,
    have9:0,

   musicplaying:1

};