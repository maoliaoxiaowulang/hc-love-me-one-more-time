import { _decorator, Component, Node, Canvas, director} from 'cc';
import { global3 } from './global3';
const { ccclass, property } = _decorator;

@ccclass('guanqia3')
export class guanqia2 extends Component {
      

    @property(Canvas)
    canvas13: Canvas = null;

    @property(Canvas)
    canvas14: Canvas = null;

    @property(Canvas)
    canvas15: Canvas = null;

    @property(Canvas)
    canvas16: Canvas = null;

    @property(Canvas)
    canvas17: Canvas = null;

    @property(Canvas)
    canvas18: Canvas = null;
    
   /* @property(Button)
    returnButton: Button = null;
    */
    

    start() {
       
        
        // 默认隐藏所有画布
        this.hideAllCanvases();
        this.onShowCanvas(global3.canvasname3);
        //this.returnButton.node.on('click', this.onReturnButtonClick, this);
    }

    // 显示指定的 canvas 并隐藏其他 canvas
    onShowCanvas(canvasName: string) {
        this.hideAllCanvases();  // 隐藏所有 canvas
        
        // 根据 canvasName 显示对应的 canvas
        switch (canvasName) {
            case 'canvas13':
                this.canvas13.node.active = true;
                break;
            case 'canvas14':
                this.canvas14.node.active = true;
                break;
            case 'canvas15':
                this.canvas15.node.active = true;
                break;
            case 'canvas16':
                this.canvas16.node.active = true;
                break;
            case 'canvas17':
                this.canvas17.node.active = true;
                break;
            case 'canvas18':
                this.canvas18.node.active = true;
                break;
        }
    }

    // 隐藏所有 canvas
    hideAllCanvases() {
        this.canvas13.node.active = false;
        this.canvas14.node.active = false;
        this.canvas15.node.active = false;
        this.canvas16.node.active = false;
        this.canvas17.node.active = false;
        this.canvas18.node.active = false;
    }

    /*onDestroy() {
        // 在场景销毁时移除事件监听
        director.getScene().off('showCanvas', this.onShowCanvas, this);
    }
    onReturnButtonClick() {
        director.loadScene('chuangguanxuanze1');
    }
    */
}