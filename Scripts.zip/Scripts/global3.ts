export const global3 = {
    canvasname3: null,  // 初始化为 null
   
};
