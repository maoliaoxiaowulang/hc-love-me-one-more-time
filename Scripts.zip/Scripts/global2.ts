export const global2 = {
    canvasname2: null,  // 初始化为 null
   
};