export const global4 = {
    canvasname4: null,  // 初始化为 null
   
};