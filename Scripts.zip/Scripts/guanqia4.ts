import { _decorator, Component, Node, Canvas, director} from 'cc';
import { global4 } from './global4';
const { ccclass, property } = _decorator;

@ccclass('guanqia4')
export class guanqia4 extends Component {
      

    @property(Canvas)
    canvas19: Canvas = null;

    @property(Canvas)
    canvas20: Canvas = null;

    @property(Canvas)
    canvas21: Canvas = null;

    @property(Canvas)
    canvas22: Canvas = null;

    @property(Canvas)
    canvas23: Canvas = null;

    @property(Canvas)
    canvas24: Canvas = null;
    
   /* @property(Button)
    returnButton: Button = null;
    */
    

    start() {
       
        
        // 默认隐藏所有画布
        this.hideAllCanvases();
        this.onShowCanvas(global4.canvasname4);
        //this.returnButton.node.on('click', this.onReturnButtonClick, this);
    }

    // 显示指定的 canvas 并隐藏其他 canvas
    onShowCanvas(canvasName: string) {
        this.hideAllCanvases();  // 隐藏所有 canvas
        
        // 根据 canvasName 显示对应的 canvas
        switch (canvasName) {
            case 'canvas19':
                this.canvas19.node.active = true;
                break;
            case 'canvas20':
                this.canvas20.node.active = true;
                break;
            case 'canvas21':
                this.canvas21.node.active = true;
                break;
            case 'canvas22':
                this.canvas22.node.active = true;
                break;
            case 'canvas23':
                this.canvas23.node.active = true;
                break;
            case 'canvas24':
                this.canvas24.node.active = true;
                break;
        }
    }

    // 隐藏所有 canvas
    hideAllCanvases() {
        this.canvas19.node.active = false;
        this.canvas20.node.active = false;
        this.canvas21.node.active = false;
        this.canvas22.node.active = false;
        this.canvas23.node.active = false;
        this.canvas24.node.active = false;
    }

    /*onDestroy() {
        // 在场景销毁时移除事件监听
        director.getScene().off('showCanvas', this.onShowCanvas, this);
    }
    onReturnButtonClick() {
        director.loadScene('chuangguanxuanze1');
    }
    */
}