import { _decorator, Component,director,Sprite,Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('UI1')
export class UI1 extends Component {
    BackToChoose1(){
        director.loadScene("1-Main")
    }
}


