import { _decorator, Component,director,Sprite,Node,Canvas } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('StartUI')
export class StartUI extends Component {
@property(Canvas)
canvasHelp: Canvas = null;    
    
    onstartButtonClick(){
        director.loadScene("chuangguanxuanze1")
    }
    onButtonClick(){
        director.loadScene("2-return")
    }

    onyesClick(){
        director.loadScene("1-Main")
    }

    onnoClick(){
        director.loadScene("2-chengjiu")
    }


    onreturnButtonClick(){
        director.loadScene("1-Main")
    }

    onBackToChoose1(){
        director.loadScene("chuangguanxuanze1")
    }
    onBackToChoose2(){
        director.loadScene("chuangguanxuanze2")
    }
    onBackToChoose3(){
        director.loadScene("chuangguanxuanze3")
    }
    onBackToChoose4(){
        director.loadScene("chuangguanxuanze4")
    }

    next2(){
        director.loadScene("chuangguanxuanze4")
    }

    onHelpButtonClick(){
        this.canvasHelp.node.active = true;
      
    }

    onguanbiClick(){
        this.canvasHelp.node.active = false;
       
    }
    
    onshop(){
        director.loadScene("2-Shop")
    }
    offshop(){
        director.loadScene("1-Main")
    }
    onachievement(){
        director.loadScene("3-chengjiu")
    }
    offachievement(){
        director.loadScene("1-Main")
    }
    

}


