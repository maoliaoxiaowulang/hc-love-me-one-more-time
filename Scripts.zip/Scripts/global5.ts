export const global5 = {
    canvasname5: null,  // 初始化为 null
   
};