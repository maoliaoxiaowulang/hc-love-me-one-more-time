import { _decorator, Component, Node,Button, director } from 'cc';
import { global } from './global';
const { ccclass, property } = _decorator;

@ccclass('turnaround')
export class turnaround extends Component {
 

@property(Node)
Anniu:Node=null

start() {
this.Anniu.on(Node.EventType.TOUCH_START, this.sendturn, this);

 }



update(deltaTime: number) {

 }

sendturn(){
if(global.currentnode){
    global.currentnode.angle += 90;
}
}
}
    



