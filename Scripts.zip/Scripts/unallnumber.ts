import { _decorator, Color, Component, Graphics, Vec2,Sprite, AudioClip,EventTouch, Vec3, v3,Node, v2,dragonBones, Camera,instantiate,Prefab, sp, Label,director,Canvas} from 'cc';
const { ccclass, property } = _decorator;
const { CCArmatureDisplay } = dragonBones;;


import { globalstarnum } from './unlock';


@ccclass('aim')
export class aim extends Component {

    @property(Label)
    starLabel:Label=null;

start(){
   
    globalstarnum.startotal=globalstarnum.starnum1+globalstarnum.starnum2+globalstarnum.starnum3+globalstarnum.starnum4+globalstarnum.starnum5+globalstarnum.starnum6+globalstarnum.starnum7+globalstarnum.starnum8+globalstarnum.starnum9+globalstarnum.starnum10+globalstarnum.starnum11+
    globalstarnum.starnum12+globalstarnum.starnum13+globalstarnum.starnum14+globalstarnum.starnum15+globalstarnum.starnum16+globalstarnum.starnum17+globalstarnum.starnum18+globalstarnum.starnum19+globalstarnum.starnum20+globalstarnum.starnum21+globalstarnum.starnum22+globalstarnum.starnum23+globalstarnum.starnum24
 this.starLabel.string=`${globalstarnum.startotal}/72`;
}






}