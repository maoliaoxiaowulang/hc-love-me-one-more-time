import { _decorator, Color, Component, Graphics, Vec2,Sprite, EventTouch, Vec3, v3,Node, v2,instantiate, Prefab, Camera, director} from 'cc';
export const global = {
    canvasname: null,  // 初始化为 null
    currentnode: null,
}
