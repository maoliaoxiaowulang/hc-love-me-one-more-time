import { _decorator, Color, Component, Graphics, Vec2,Sprite, AudioClip,EventTouch, Vec3, v3,Node, v2,dragonBones, Camera,instantiate,Prefab, sp, Label,director,Canvas} from 'cc';
const { ccclass, property } = _decorator;
const { CCArmatureDisplay } = dragonBones;;


import { globalstarnum } from './unlock';


@ccclass('aim')
export class aim extends Component {

    @property(Label)
    starLabel:Label=null;

    @property(Node)
    buy1:Node=null;
    @property(Node)
    buy2:Node=null;
    @property(Node)
    buy3:Node=null;
    @property(Node)
    nobuy1:Node=null;
    @property(Node)
    nobuy2:Node=null;
    @property(Node)
    nobuy3:Node=null;


start(){
    this.nobuy1.active=false;
    this.nobuy2.active=false;
    this.nobuy3.active=false;
    this.buy1.active=false;
    this.buy2.active=false;
    this.buy3.active=false;
   globalstarnum.leftstar=globalstarnum.startotal-globalstarnum.coststar;
   this.starLabel.string=`${globalstarnum.leftstar}`;
   if(globalstarnum.leftstar<1){this.nobuy1.active=true;this.nobuy2.active=true;this.nobuy3.active=true;this.buy1.active=false;this.buy2.active=false;this.buy3.active=false;}
   else if(globalstarnum.leftstar<3){this.buy1.active=true;this.nobuy2.active=true;this.nobuy3.active=true;this.nobuy1.active=false;this.buy2.active=false;this.buy3.active=false;}
   else if(globalstarnum.leftstar<5){this.buy1.active=true;this.buy2.active=true;this.nobuy3.active=true;this.nobuy1.active=false;this.nobuy2.active=false;this.buy3.active=false;}
   else {this.buy1.active=true;this.buy2.active=true;this.buy3.active=true;this.nobuy1.active=false;this.nobuy2.active=false;this.nobuy3.active=false;}
}

onbuyone(){
    if(globalstarnum.leftstar>0)
    {globalstarnum.coststar+=1;
    globalstarnum.bigglassnum+=1;
    globalstarnum.leftstar=globalstarnum.startotal-globalstarnum.coststar;
    this.starLabel.string=`${globalstarnum.leftstar}`;}
   
    if(globalstarnum.leftstar<1){this.nobuy1.active=true;this.nobuy2.active=true;this.nobuy3.active=true;this.buy1.active=false;this.buy2.active=false;this.buy3.active=false;}
    else if(globalstarnum.leftstar<3){this.buy1.active=true;this.nobuy2.active=true;this.nobuy3.active=true;this.nobuy1.active=false;this.buy2.active=false;this.buy3.active=false;}
    else if(globalstarnum.leftstar<5){this.buy1.active=true;this.buy2.active=true;this.nobuy3.active=true;this.nobuy1.active=false;this.nobuy2.active=false;this.buy3.active=false;}
    else {this.buy1.active=true;this.buy2.active=true;this.buy3.active=true;this.nobuy1.active=false;this.nobuy2.active=false;this.nobuy3.active=false;}

}
onbuytwo(){
    if(globalstarnum.leftstar>=3){
    globalstarnum.coststar+=3;
    globalstarnum.leidanum+=1;
    globalstarnum.leftstar=globalstarnum.startotal-globalstarnum.coststar;
    this.starLabel.string=`${globalstarnum.leftstar}`;}
  

    if(globalstarnum.leftstar<1){this.nobuy1.active=true;this.nobuy2.active=true;this.nobuy3.active=true;this.buy1.active=false;this.buy2.active=false;this.buy3.active=false;}
    else if(globalstarnum.leftstar<3){this.buy1.active=true;this.nobuy2.active=true;this.nobuy3.active=true;this.nobuy1.active=false;this.buy2.active=false;this.buy3.active=false;}
    else if(globalstarnum.leftstar<5){this.buy1.active=true;this.buy2.active=true;this.nobuy3.active=true;this.nobuy1.active=false;this.nobuy2.active=false;this.buy3.active=false;}
    else {this.buy1.active=true;this.buy2.active=true;this.buy3.active=true;this.nobuy1.active=false;this.nobuy2.active=false;this.nobuy3.active=false;}
}
onbuythree(){
    if(globalstarnum.leftstar>=5){
    globalstarnum.coststar+=5;
    globalstarnum.rocketnum+=1;
    globalstarnum.leftstar=globalstarnum.startotal-globalstarnum.coststar;
    this.starLabel.string=`${globalstarnum.leftstar}`;}
    

    if(globalstarnum.leftstar<1){this.nobuy1.active=true;this.nobuy2.active=true;this.nobuy3.active=true;this.buy1.active=false;this.buy2.active=false;this.buy3.active=false;}
    else if(globalstarnum.leftstar<3){this.buy1.active=true;this.nobuy2.active=true;this.nobuy3.active=true;this.nobuy1.active=false;this.buy2.active=false;this.buy3.active=false;}
    else if(globalstarnum.leftstar<5){this.buy1.active=true;this.buy2.active=true;this.nobuy3.active=true;this.nobuy1.active=false;this.nobuy2.active=false;this.buy3.active=false;}
    else {this.buy1.active=true;this.buy2.active=true;this.buy3.active=true;this.nobuy1.active=false;this.nobuy2.active=false;this.nobuy3.active=false;}
}



}