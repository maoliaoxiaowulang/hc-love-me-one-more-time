import { _decorator, Component, Node, Button, director } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('xuanguantiaozhuan')
export class xuanguantiaozhuan extends Component {
    @property(Button)
    changjing1: Button = null!;  // 第一个按钮，用于跳转到 'chuangguanxuanze'
    @property(Button)
    changjing2: Button = null!;
    @property(Button)
    changjing3: Button = null!;
    @property(Button)
    changjing4: Button = null!;

    @property(Button)
    chuangguanreturn: Button = null!;  // 第二个按钮，用于返回到 '2-Main'

    start() {
        // 为按钮添加点击事件监听
        this.changjing1.node.on('click', this.onChangjing1Click, this);
        this.changjing2.node.on('click', this.onChangjing1Click, this);
        this.changjing3.node.on('click', this.onChangjing1Click, this);
        this.changjing4.node.on('click', this.onChangjing1Click, this);
        this.chuangguanreturn.node.on('click', this.onChuangguanReturnClick, this);
    }

    // 第一个按钮的点击事件处理函数：跳转到 'chuangguanxuanze'
    onChangjing1Click() {
        director.loadScene('chuangguanxuanze1');
    }
    onChangjing2Click() {
        director.loadScene('chuangguanxuanze2');
    }
    onChangjing3Click() {
        director.loadScene('chuangguanxuanze3');
    }
    onChangjing4Click() {
        director.loadScene('chuangguanxuanze4');
    }

    // 第二个按钮的点击事件处理函数：跳转到 '2-Main'
    onChuangguanReturnClick() {
        director.loadScene('2-Main');
    }

    update(deltaTime: number) {
        // 你可以在这里添加其他需要的更新逻辑
    }
}




