import { _decorator, Color, Component, Graphics, Vec2,Sprite, EventTouch, Vec3, v3,Node, v2,dragonBones, Camera,instantiate,Prefab, sp, Label,Button,Canvas,director} from 'cc';
const { ccclass, property } = _decorator;

@ccclass('1-Main')
export class Main extends Component {

    start() {
       
        const scenesToPreload = ['chuangguanxuanze2','chuangguanxuanze3'];
}
}


// 'guanqia2', 'guanqia3', 'guanqia4',,,'chuangguanxuanze4','guanqia',